from machine import I2C,UART,Pin,PWM
from  Sengo1  import *
import time
from neopixel import myNeopixel

# 等待Sengo1完成操作系统的初始化。此等待时间不可去掉，避免出现Sengo1尚未初始化完毕主控器已经开发发送指令的情况
time.sleep(3)

# 选择UART或者I2C通讯模式，Sengo1出厂默认为I2C模式，短按模式按键可以切换
# 4种UART通讯模式：UART9600（标准协议指令），UART57600（标准协议指令），UART115200（标准协议指令），Simple9600（简单协议指令），
#########################################################################################################
# port = UART(2,rx=Pin(16),tx=Pin(17),baudrate=9600)
port = I2C(0,scl=Pin(21),sda=Pin(20),freq=400000)

# Sengo1通讯地址：0x60。如果I2C总线挂接多个设备，请避免出现地址冲突
sengo1 = Sengo1(0x60)

err = sengo1.begin(port)
print("sengo1.begin: 0x%x"% err)
 
# 1、sengo1消费版可以储存10张人脸数据
# 2、除了可以通过操作摇杆记忆/删除人脸数据外，还可以通过串口指令进行操作；
# 3、正常使用时，应由主控器发送指令控制sengo1算法的开启与关闭，而非通过摇杆手动进行操作；
err = sengo1.VisionBegin(sengo1_vision_e.kVisionFace)
print("sengo1.VisionBegin(sengo1_vision_e.kVisionFace):0x%x"% err)

#Initialize the passive buzzer
buzzer = PWM(Pin(12))

#Define the number of pin and LEDs connected to neopixel.
NUM_LEDS = 4
np = myNeopixel(NUM_LEDS, 13)
np.brightness(150) #brightness: 0 ~ 255

previousMillis = 0
lastDetectionTime = 0
disappearDelay = 5000  # 1000ms = 1s
currentFaceDetected = False


def play_success_sound():
    """正确提示音（清脆的两短音）"""
    for i in range(2):
        buzzer.freq(1500)    # 1500Hz高频
        buzzer.duty_u16(32768)  # 50%占空比(65536/2)
        time.sleep_ms(100)    # 持续100ms
        buzzer.duty_u16(0)   # 关闭声音
        time.sleep_ms(50)     # 短音间隔50ms

def play_error_sound():
    """错误提示音（低沉的单长音）"""
    buzzer.freq(300)        # 300Hz低频
    buzzer.duty_u16(32768)  # 50%占空比
    time.sleep_ms(500)       # 持续500ms
    buzzer.duty_u16(0)      # 关闭声音


while True:
    # sengo1不主动返回检测识别结果，需要主控板发送指令进行读取。读取的流程：首先读取识别结果的数量，接收到指令后，Sengo1会刷新结果数据，如果结果数量不为零，那么主控再发送指令读取结果的相关信息。请务必按此流程构建程序。
    obj_num = sengo1.GetValue(sengo1_vision_e.kVisionFace, sentry_obj_info_e.kStatus)
    #获取运行时间
    currentMillis = time.ticks_ms()
    if obj_num:        
        #人脸标签=0，表示陌生人；人脸标签范围1-10，表示已经记忆的人脸；
        l = sengo1.GetValue(sengo1_vision_e.kVisionFace, sentry_obj_info_e.kLabel)
        #判断是否识别到人脸1并且currentFaceDetected是否等于Fasle
        if l == 1 and not currentFaceDetected:
            #将起始时间设置为当前时间然后在进行5秒计算
            lastDetectionTime = currentMillis
            #将currentFaceDetected设置成True，将不在进入当前if中
            currentFaceDetected = True
            #WS2812亮绿灯
            np.fill(0, 255, 0)
            np.show()
            #发出识别成功生意
            play_success_sound()
            time.sleep(0.2)
            #熄灭WS2812灯
            np.fill(0, 0, 0)
            np.show()
        #如果是新人脸
        elif l == 0:
            #WS2812亮红灯
            np.fill(255, 0, 0)
            np.show()
            #发出识别失败声音
            play_error_sound()
            time.sleep(0.2)
            #熄灭WS2812灯
            np.fill(0, 0, 0)
            np.show()
    #延时0.3秒
    time.sleep(0.3)
    #5秒延时代码，成功识别正确人脸后5秒内将不会再次识别正确人脸
    if currentFaceDetected and (currentMillis - lastDetectionTime >= disappearDelay):
        #设置currentFaceDetected为False才能进入正确人脸代码
        currentFaceDetected = False
            

